<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="footer">

        <h4>Contact Us:</h4>
        
        <img src="/asset/Instagram_icon.png" alt="" style="width:80px;height:80px;">
        <img src="/asset/twitter_icon.png" alt="" style="width:80px;height:80px;">
        <img src="/asset/facebook_icon.png" alt="" style="width:80px;height:80px;">
       
    </div>
</body>
</html><?php /**PATH /Users/andersonpieter/Documents/GSLC_WebProgramming_Week_5/resources/views/footer.blade.php ENDPATH**/ ?>